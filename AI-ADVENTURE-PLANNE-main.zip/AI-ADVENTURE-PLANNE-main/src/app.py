import streamlit as st
from streamlit_option_menu import option_menu
from pages.home import show_home
from pages.planner import show_planner
from pages.suggestions import show_suggestions
import json

# Page configuration
st.set_page_config(
    page_title="AI Adventure Planner",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Hide default sidebar content and only show app name
st.markdown("""
    <style>
        [data-testid="collapsedControl"] {
            display: none
        }
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        .stDeployButton {display:none;}
        .main {
            padding: 0rem 1rem;
        }
        section[data-testid="stSidebar"] > div {
            padding-top: 2rem;
            background-color: #f8fafc;
        }
        section[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] {
            padding: 0 1rem;
        }
        section[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] > div > p {
            font-size: 1.25rem;
            font-weight: bold;
            color: #111827;
        }
        .stButton>button {
            width: 100%;
            border-radius: 10px;
            height: 3rem;
            background-color: #0EA5E9;
            color: white;
            font-weight: bold;
        }
        .stButton>button:hover {
            background-color: #0284C7;
            border-color: #0284C7;
        }
        .feature-card {
            padding: 1.5rem;
            border-radius: 10px;
            background-color: white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.12);
            margin-bottom: 1rem;
        }
        .feature-card:hover {
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transform: translateY(-2px);
            transition: all 0.2s ease;
        }
        h1, h2, h3 {
            color: #111827;
        }
        p {
            color: #4B5563;
        }
        div[data-testid="stStatusWidget"] {
            display: none !important;
        }
    </style>
""", unsafe_allow_html=True)

# Only show the app name in the sidebar
st.sidebar.title("AI Adventure Planner")

# Initialize session state
if 'page' not in st.session_state:
    st.session_state.page = 'Home'
if 'adventure_plan' not in st.session_state:
    st.session_state.adventure_plan = None

# Get the current page from query params or session state
current_page = st.query_params.get("page", st.session_state.page)

# Hide warning messages
st.markdown("""
    <style>
        div[data-testid="stStatusWidget"] {
            display: none !important;
        }
    </style>
""", unsafe_allow_html=True)

# Top navigation
selected = option_menu(
    menu_title=None,
    options=["Home", "Plan Adventure", "View Suggestions"],
    icons=["house", "map", "list-check"],
    menu_icon="cast",
    default_index=["Home", "Plan Adventure", "View Suggestions"].index(current_page),
    orientation="horizontal",
    styles={
        "container": {"padding": "0!important", "background-color": "#f8fafc"},
        "icon": {"color": "#0EA5E9", "font-size": "25px"}, 
        "nav-link": {
            "font-size": "16px",
            "text-align": "center",
            "margin": "0px",
            "--hover-color": "#EFF6FF",
        },
        "nav-link-selected": {"background-color": "#0EA5E9", "color": "white"},
    }
)

# Update session state and query params based on selection
if selected != current_page:
    st.session_state.page = selected
    st.query_params["page"] = selected
    st.rerun()

# Page routing
if selected == "Home":
    show_home()
elif selected == "Plan Adventure":
    show_planner()
elif selected == "View Suggestions":
    show_suggestions() 