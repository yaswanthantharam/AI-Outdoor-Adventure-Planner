import streamlit as st
import google.generativeai as genai
from datetime import datetime
import json
import time
import os
from dotenv import load_dotenv
import random

# Load environment variables
load_dotenv()

# Configure Gemini AI
genai.configure(api_key='AIzaSyA9lKWRihj_77D83ifVdHWYGLZoPW1M84Q')
model = genai.GenerativeModel('gemini-1.5-flash')

def sleep_with_exponential_backoff(attempt):
    """Sleep with exponential backoff (faster for testing)."""
    sleep_time = min(5, (1 * (2 ** (attempt - 1))) + (random.uniform(0, 0.5)))  # Cap at 5 seconds
    time.sleep(sleep_time)
    return sleep_time

def generate_adventure_plan(preferences):
    prompt = f"""Create a structured travel plan with the following preferences:
    Destination: {preferences['destination']}
    Budget: {preferences['budget']}
    Duration: {preferences['duration']}
    Interests: {', '.join(preferences['interests'])}
    Travel Style: {preferences['travel_style']}

    Please provide:
    1. Recommended destinations and why they match the preferences
    2. Day-by-day itinerary
    3. Budget breakdown
    4. Essential packing list
    5. Local insights and tips
    """

    max_retries = 2  # Reduced for faster testing
    attempt = 0

    while attempt < max_retries:
        try:
            response = model.generate_content(prompt)
            return response.text
        except Exception as e:
            attempt += 1
            error_msg = str(e)
            
            if "503" in error_msg:  # Service Unavailable
                if attempt < max_retries:
                    sleep_time = sleep_with_exponential_backoff(attempt)
                    st.warning(f"API is temporarily overloaded. Retrying in {sleep_time:.1f} seconds... (Attempt {attempt}/{max_retries})")
                    continue
                else:
                    st.error("Maximum retries reached. Please try again later.")
            else:
                st.error(f"Error generating plan: {error_msg}")
            return None

def show_planner():
    st.title("Plan Your Adventure")
    st.markdown("Tell us about your dream adventure, and we'll create a personalized plan for you.")

    with st.form("adventure_form"):
        # Destination
        destination = st.text_input(
            "Destination",
            placeholder="e.g., Japan, Europe, etc.",
            help="Enter your desired destination or leave blank for suggestions"
        )

        # Budget
        budget = st.selectbox(
            "Budget Range",
            options=["Budget ($500-$1000)", "Moderate ($1000-$3000)", "Luxury ($3000+)"],
            help="Select your budget range"
        )

        # Duration
        duration = st.selectbox(
            "Duration",
            options=["Weekend (2-3 days)", "Week (7-10 days)", "Extended (2+ weeks)"],
            help="Select your trip duration"
        )

        # Interests
        st.markdown("### Interests")
        col1, col2 = st.columns(2)
        
        with col1:
            interest_adventure = st.checkbox("Adventure")
            interest_culture = st.checkbox("Culture")
            interest_food = st.checkbox("Food")
        
        with col2:
            interest_nature = st.checkbox("Nature")
            interest_relaxation = st.checkbox("Relaxation")
            interest_shopping = st.checkbox("Shopping")

        interests = []
        if interest_adventure: interests.append("Adventure")
        if interest_culture: interests.append("Culture")
        if interest_food: interests.append("Food")
        if interest_nature: interests.append("Nature")
        if interest_relaxation: interests.append("Relaxation")
        if interest_shopping: interests.append("Shopping")

        # Travel Style
        travel_style = st.select_slider(
            "Travel Style",
            options=["Relaxed", "Balanced", "Fast-paced"],
            value="Balanced",
            help="Choose your preferred travel pace"
        )

        # Submit button
        submitted = st.form_submit_button("Generate Plan")

        if submitted:
            if not interests:
                st.error("Please select at least one interest.")
                return

            with st.spinner("Generating your personalized adventure plan..."):
                preferences = {
                    "destination": destination,
                    "budget": budget,
                    "duration": duration,
                    "interests": interests,
                    "travel_style": travel_style
                }

                adventure_plan = generate_adventure_plan(preferences)
                
                if adventure_plan:
                    st.session_state.adventure_plan = adventure_plan
                    st.session_state.page = "View Suggestions"
                    st.rerun() 