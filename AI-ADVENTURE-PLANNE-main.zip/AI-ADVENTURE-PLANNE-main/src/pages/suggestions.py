import streamlit as st

def show_suggestions():
    if not st.session_state.adventure_plan:
        st.warning("No adventure plan found. Please create one first!")
        if st.button("Create Adventure Plan"):
            st.session_state.page = "Plan Adventure"
            st.rerun()
        return

    st.title("Your Adventure Plan")
    
    # Display the adventure plan in a nice format
    with st.container(border=True):
        st.markdown(st.session_state.adventure_plan)

    # Action buttons
    col1, col2, col3 = st.columns([1, 1, 1])
    
    with col1:
        if st.button("Create New Plan"):
            st.session_state.adventure_plan = None
            st.session_state.page = "Plan Adventure"
            st.rerun()
    
    with col2:
        if st.download_button(
            label="Download Plan",
            data=st.session_state.adventure_plan,
            file_name="adventure_plan.txt",
            mime="text/plain"
        ):
            st.success("Plan downloaded successfully!")
    
    with col3:
        if st.button("Share Plan"):
            st.info("Sharing functionality coming soon!") 