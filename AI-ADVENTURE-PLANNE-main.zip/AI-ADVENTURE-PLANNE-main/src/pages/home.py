import streamlit as st
from streamlit_lottie import st_lottie
import requests

def load_lottie_url(url: str):
    try:
        r = requests.get(url)
        if r.status_code != 200:
            return None
        return r.json()
    except:
        return None

def show_home():
    # Header
    st.title("🌍 Welcome to AI Adventure Planner")
    st.markdown("""
    Your personal AI-powered travel companion that helps create unforgettable adventures tailored just for you!
    """)

    # Main sections in columns
    col1, col2 = st.columns([3, 2])

    with col1:
        st.markdown("### 🚀 Get Started")
        st.markdown("""
        1. Fill out your travel preferences
        2. Let our AI create a personalized plan
        3. Review and customize your adventure
        4. Download or share your itinerary
        """)

        st.markdown("### ✨ Key Features")
        
        # Feature cards
        with st.container():
            st.markdown("""
            <div class="feature-card">
                <h4>🎯 Smart Destination Matching</h4>
                <p>AI-powered suggestions based on your interests and preferences</p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("""
            <div class="feature-card">
                <h4>📅 Detailed Itineraries</h4>
                <p>Day-by-day plans optimized for your travel style</p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("""
            <div class="feature-card">
                <h4>💰 Budget Planning</h4>
                <p>Comprehensive cost breakdowns and money-saving tips</p>
            </div>
            """, unsafe_allow_html=True)

    with col2:
        # Loading animation
        lottie_travel = load_lottie_url("https://assets5.lottiefiles.com/packages/lf20_UgZWvP.json")
        if lottie_travel:
            st_lottie(lottie_travel, height=300)

    # Call to action
    st.markdown("---")
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        if st.button("Start Planning Your Adventure", use_container_width=True):
            st.session_state["page"] = "Plan Adventure"
            st.query_params["page"] = "Plan Adventure"
            st.rerun() 